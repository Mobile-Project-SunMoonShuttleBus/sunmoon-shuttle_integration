exports.num = 1;

exports.add = (a, b) => {
    return a + b;
};

exports.sub = (a, b) => {
    return a - b;
}
