const calc = require('./calc');
console.log(calc.num);	// 1

let res = calc.add(10, 5);
console.log(res);		// 4

res = calc.sub(10, 5);
console.log(res);	